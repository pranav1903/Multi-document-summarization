# IRproject

# Installing Dependencies:
import Flask

pip install werkzeug.utils

import request

import jsonify

import os

import traceback

import pathlib

import textwrap

import google.generativeai

import GoogleTranslator

import pytesseract

import PegasusTokenizer

import AutoTokenizer


# Running the website
In the folder mobby open a new terminal.


Run python3 app.py

Ensure all dependencies are pre-installed.
